import Foundation

// ======================================================================
// MARK: - مدير المصادقة مع الخادم الخلفي
// ======================================================================

final class AuthManager {
    static let shared = AuthManager()
    private init() {}
    
    // التوكن الثابت (يمكن تخزينه في الإعدادات لاحقاً)
    private let authToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY4YWY3YjYzNzc1OGE1N2NmNWZkNjc3MyIsImdvb2dsZUlkIjoiMTAzOTQ3NzE2NTgyMDk5Mzc0MDY4IiwibmFtZSI6IlplIHVzIiwiZW1haWwiOiJjb2JyYXBrOGdnZ0BnbWFpbC5jb20iLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUNnOG9jS210RjA5OFBZVTlha1hTX2s4T24zNDBuRW5ZZmM0VzBIUXZxR2t4VnYxd2dWZU04OD1zOTYtYyIsImlhdCI6MTc1OTM5NTA1NywiZXhwIjoxNzU5OTk5ODU3fQ.L08H0FBZncwwpVj50jG0P4ujyq5cIUyyOPMPyxiAItQ" // ضع التوكن هنا
    
    var token: String {
        return authToken
    }
    
    // عنوان الخادم
    let baseURL = "https://chatzeusb.vercel.app"
    
    // التحقق من صحة التوكن
    func validateToken(completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "\(baseURL)/api/user") else {
            completion(false)
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ خطأ في التحقق من التوكن: \(error)")
                completion(false)
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse,
               httpResponse.statusCode == 200 {
                completion(true)
            } else {
                completion(false)
            }
        }.resume()
    }
}
