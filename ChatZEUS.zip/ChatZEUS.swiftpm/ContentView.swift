import SwiftUI
import WebKit
import UniformTypeIdentifiers
import AVFoundation

// MARK: - موديل الفصل
struct ChapterFile: Identifiable {
    let id = UUID()
    let number: Int
    let title: String
    let content: String
}

// MARK: - المحرك الذكي الشامل (Universal Zeus Engine)
class ZeusScraperEngine: NSObject, ObservableObject {
    @Published var status: String = "جاهز..."
    @Published var isRunning: Bool = false
    @Published var logs: String = "ZEUS Universal Engine Initialized...\n"
    @Published var chaptersStore: [ChapterFile] = []
    @Published var showExportSheet: Bool = false
    @Published var zipURL: URL?
    
    // قائمة الكلمات المحظورة (يتم حفظها تلقائياً)
    @Published var blacklist: [String] {
        didSet {
            UserDefaults.standard.set(blacklist, forKey: "user_blacklist")
        }
    }
    
    @Published var currentBrowserURL: String {
        didSet {
            UserDefaults.standard.set(currentBrowserURL, forKey: "lastSavedURL")
        }
    }
    
    var webView: WKWebView?
    var novelTitle: String = "Novel"
    var chapterLinksQueue: [String] = []
    var currentQueueIndex: Int = 0
    var displayChapterNumber: Int = 1
    var isProcessing: Bool = false
    
    override init() {
        self.currentBrowserURL = UserDefaults.standard.string(forKey: "lastSavedURL") ?? "https://google.com"
        self.blacklist = UserDefaults.standard.stringArray(forKey: "user_blacklist") ?? ["ديسكورد", "انضم إلينا", "تابعنا على"]
        super.init()
    }
    
    func log(_ message: String) {
        DispatchQueue.main.async {
            self.logs = "> [\(self.getTime())] \(message)\n" + self.logs
        }
    }
    
    func getTime() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: Date())
    }
    
    // دالة مسح كافة البيانات وتفريغ الذاكرة
    func clearAllData() {
        self.chaptersStore.removeAll()
        self.chapterLinksQueue.removeAll()
        self.currentQueueIndex = 0
        self.zipURL = nil
        self.logs = "> [\(self.getTime())] 🗑️ تم مسح جميع البيانات وتفريغ الذاكرة.\n"
        self.status = "جاهز..."
        
        // مسح الملفات المؤقتة من الجهاز
        let tempDir = FileManager.default.temporaryDirectory
        try? FileManager.default.contentsOfDirectory(at: tempDir, includingPropertiesForKeys: nil).forEach { url in
            try? FileManager.default.removeItem(at: url)
        }
    }
    
    func analyzeCurrentPage(startCh: Int) {
        guard let url = webView?.url?.absoluteString else {
            self.log("❌ لا يوجد رابط نشط.")
            return
        }
        
        self.log("🧠 جاري التحليل الذكي للصفحة...")
        self.chaptersStore = []
        self.chapterLinksQueue = []
        self.currentQueueIndex = 0
        self.displayChapterNumber = startCh
        self.isRunning = true
        self.isProcessing = false
        
        self.smartExtractChapters()
    }
    
    func stop() {
        self.isRunning = false
        self.status = "تم الإيقاف يدوياً"
        self.log("🛑 تم إيقاف العمليات.")
    }
    
    func loadURL(_ urlString: String) {
        guard let url = URL(string: urlString) else {
            if let encoded = urlString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
               let urlFallback = URL(string: encoded) {
                DispatchQueue.main.async { self.webView?.load(URLRequest(url: urlFallback)) }
            }
            return
        }
        DispatchQueue.main.async {
            self.webView?.load(URLRequest(url: url))
        }
    }
    
    func handlePageFinished() {
        if let url = webView?.url?.absoluteString {
            DispatchQueue.main.async {
                self.currentBrowserURL = url
            }
        }
        
        webView?.evaluateJavaScript("document.title") { result, _ in
            if let title = result as? String, (title.contains("Just a moment") || title.contains("Cloudflare")) {
                self.log("⚠️ حماية Cloudflare نشطة...")
                return
            }
            
            guard self.isRunning, !self.isProcessing else { return }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                self.isProcessing = true
                if self.chapterLinksQueue.isEmpty {
                    self.smartExtractChapters()
                } else {
                    self.log("⬇️ سحب محتوى الفصل..")
                    self.smartExtractContent()
                }
            }
        }
    }
    
    // MARK: - الذكاء الاصطناعي للاستخراج
    
    func smartExtractChapters() {
        let js = """
        (function() {
            let h1 = document.querySelector('h1');
            let title = h1 ? h1.innerText.trim() : document.title;
            let allLinks = Array.from(document.querySelectorAll('a'));
            let candidates = allLinks.filter(a => {
                let href = a.href;
                let text = a.innerText.trim();
                return href && href.startsWith('http') && text.length > 0 && /\\d+/.test(href + text); 
            });
            let parentsMap = new Map();
            candidates.forEach(link => {
                let parent = link.parentElement.parentElement;
                if(!parent) return;
                if (!parentsMap.has(parent)) parentsMap.set(parent, []);
                parentsMap.get(parent).push(link.href);
            });
            let bestList = [];
            parentsMap.forEach((links, parent) => {
                let uniqueLinks = [...new Set(links)];
                if (uniqueLinks.length > bestList.length) { bestList = uniqueLinks; }
            });
            if (bestList.length < 5) {
                 bestList = candidates.map(a => a.href).filter((v, i, a) => a.indexOf(v) === i);
            }
            return { title: title, links: bestList };
        })()
        """
        
        webView?.evaluateJavaScript(js) { result, error in
            defer { self.isProcessing = false }
            if error != nil { self.isRunning = false; return }
            
            guard let data = result as? [String: Any],
                  let title = data["title"] as? String,
                  let links = data["links"] as? [String], !links.isEmpty else {
                self.log("⚠️ فشل العثور على الفصول.")
                self.isRunning = false
                return
            }
            
            self.novelTitle = title
            self.log("📘 الرواية: \(title)")
            var finalLinks = links
            if links.count > 1 { finalLinks = links.reversed() }
            
            let startIndex = max(0, self.displayChapterNumber - 1)
            if startIndex < finalLinks.count {
                self.chapterLinksQueue = Array(finalLinks[startIndex...])
                self.log("🚀 تم جدولة \(self.chapterLinksQueue.count) فصل.")
                self.loadNextChapterInQueue()
            } else {
                self.stop()
            }
        }
    }
    
    func loadNextChapterInQueue() {
        guard isRunning else { return }
        if currentQueueIndex < chapterLinksQueue.count {
            let nextLink = chapterLinksQueue[currentQueueIndex]
            self.status = "سحب فصل \(displayChapterNumber)..."
            isProcessing = false
            loadURL(nextLink)
        } else {
            self.log("✅ اكتمل الاستخراج بنجاح!")
            self.status = "مكتمل"
            self.isRunning = false
        }
    }
    
    func smartExtractContent() {
        let js = """
        (function() {
            let specificSelectors = ['.reading-content', '.text-right', '.entry-content', '#content-canvas', '.chapter-content', '.novel-content'];
            let bestElement = null;
        
            for (let selector of specificSelectors) {
                let el = document.querySelector(selector);
                if (el && el.innerText.trim().length > 250) {
                    bestElement = el;
                    break;
                }
            }
        
            if (!bestElement) {
                function getScore(el) {
                    let text = el.innerText.trim();
                    if (text.length < 150) return 0;
                    let pCount = el.querySelectorAll('p').length;
                    let imgCount = el.querySelectorAll('img').length;
                    return text.length + (pCount * 20) - (imgCount * 30);
                }
                let candidates = document.querySelectorAll('div, article, section');
                let maxS = 0;
                candidates.forEach(c => {
                    let s = getScore(c);
                    if(s > maxS) { maxS = s; bestElement = c; }
                });
            }
        
            if (!bestElement) return { content: "" };
        
            let clone = bestElement.cloneNode(true);
            clone.querySelectorAll('script, style, iframe, ads, .ads, .social, button').forEach(n => n.remove());
            
            let paras = Array.from(clone.querySelectorAll('p, div'))
                        .map(p => p.innerText.trim())
                        .filter(t => t.length > 2);
            
            let content = paras.length > 5 ? paras.join('\\n\\n') : clone.innerText.trim();
            let title = document.querySelector('h1')?.innerText || document.title;
        
            return { title: title, content: content };
        })()
        """
        
        webView?.evaluateJavaScript(js) { result, _ in
            if let data = result as? [String: String], let rawContent = data["content"], rawContent.count > 100 {
                let title = data["title"] ?? "فصل \(self.displayChapterNumber)"
                
                let finalContent = self.processAndFilterContent(rawContent)
                
                let newChapter = ChapterFile(number: self.displayChapterNumber, title: title, content: finalContent)
                
                DispatchQueue.main.async {
                    self.chaptersStore.append(newChapter)
                    self.log("💾 تم حفظ وفلترة: \(title)")
                    self.displayChapterNumber += 1
                    self.currentQueueIndex += 1
                    self.loadNextChapterInQueue()
                }
            } else {
                self.currentQueueIndex += 1
                self.loadNextChapterInQueue()
            }
            self.isProcessing = false
        }
    }
    
    func processAndFilterContent(_ content: String) -> String {
        let lines = content.components(separatedBy: .newlines)
        
        let filteredLines = lines.filter { line in
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty { return true }
            
            for word in blacklist {
                if trimmed.lowercased().contains(word.lowercased()) {
                    return false 
                }
            }
            return true
        }
        
        return filteredLines.joined(separator: "\n\n")
    }
    
    // MARK: - تصدير ZIP
    func prepareZipExport() {
        let fileManager = FileManager.default
        let tempDir = fileManager.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        do {
            try fileManager.createDirectory(at: tempDir, withIntermediateDirectories: true)
            for chapter in chaptersStore {
                let fileURL = tempDir.appendingPathComponent("\(chapter.number).txt")
                try "\(chapter.title)\n\n\(chapter.content)".write(to: fileURL, atomically: true, encoding: .utf8)
            }
            self.zipURL = createZip(from: tempDir)
            if self.zipURL != nil { self.showExportSheet = true }
        } catch { self.log("❌ فشل إنشاء الملف.") }
    }
    
    func createZip(from directory: URL) -> URL? {
        let coordinator = NSFileCoordinator()
        var zipURL: URL?
        coordinator.coordinate(readingItemAt: directory, options: .forUploading, error: nil) { url in
            let tempZip = FileManager.default.temporaryDirectory.appendingPathComponent("Scraped_Novel_\(Date().timeIntervalSince1970).zip")
            try? FileManager.default.copyItem(at: url, to: tempZip)
            zipURL = tempZip
        }
        return zipURL
    }
}

// MARK: - واجهة المستخدم الرئيسية
struct ContentView: View {
    @StateObject var engine = ZeusScraperEngine()
    @State private var startCh: String = "1"
    @State private var isLogExpanded: Bool = false
    @State private var showBlacklist: Bool = false
    @State private var showDeleteAlert: Bool = false
    
    var body: some View {
        ZStack {
            Color(red: 0.08, green: 0.08, blue: 0.1).ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Top Header
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("ZEUS UNIVERSAL").font(.system(size: 18, weight: .black)).foregroundColor(.white)
                        Text("HYBRID EXTRACTION").font(.system(size: 10)).foregroundColor(.cyan).tracking(2)
                    }
                    Spacer()
                    
                    // زر قائمة الحظر
                    Button(action: { showBlacklist.toggle() }) {
                        Image(systemName: "shield.slash.fill")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.orange.opacity(0.3))
                            .clipShape(Circle())
                    }
                    
                    if !engine.chaptersStore.isEmpty {
                        // زر حذف جميع البيانات
                        Button(action: { showDeleteAlert = true }) {
                            Image(systemName: "trash.fill")
                                .foregroundColor(.white)
                                .padding(10)
                                .background(Color.red.opacity(0.6))
                                .clipShape(Circle())
                        }
                        
                        // زر التصدير
                        Button(action: { engine.prepareZipExport() }) {
                            HStack {
                                Image(systemName: "folder.badge.plus")
                                Text("\(engine.chaptersStore.count)")
                            }
                            .font(.caption.bold()).padding(.horizontal, 12).padding(.vertical, 8)
                            .background(Color.cyan).foregroundColor(.black).cornerRadius(10)
                        }
                    }
                }
                .padding()
                
                BrowserBarView(engine: engine)
                
                // WebView
                WebViewHelper(engine: engine)
                    .cornerRadius(15)
                    .padding(.horizontal, 10)
                    .shadow(color: .black.opacity(0.5), radius: 10)
                
                // Bottom Panel
                VStack(spacing: 0) {
                    ControlPanelView(engine: engine, startCh: $startCh, isLogExpanded: $isLogExpanded)
                    if isLogExpanded {
                        LogTerminalView(logs: engine.logs)
                    }
                }
                .background(Color(red: 0.12, green: 0.12, blue: 0.15))
                .cornerRadius(25, corners: [.topLeft, .topRight])
            }
        }
        .alert("حذف البيانات", isPresented: $showDeleteAlert) {
            Button("إلغاء", role: .cancel) { }
            Button("حذف الكل", role: .destructive) { engine.clearAllData() }
        } message: {
            Text("هل أنت متأكد من حذف جميع الفصول المحفوظة؟ سيؤدي ذلك لتفريغ الذاكرة تماماً.")
        }
        .sheet(isPresented: $showBlacklist) {
            BlacklistView(engine: engine)
        }
        .sheet(isPresented: $engine.showExportSheet) {
            if let url = engine.zipURL { ShareSheet(activityItems: [url]) }
        }
    }
}

// MARK: - واجهة قائمة الحظر
struct BlacklistView: View {
    @ObservedObject var engine: ZeusScraperEngine
    @State private var newWord: String = ""
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(red: 0.1, green: 0.1, blue: 0.12).ignoresSafeArea()
                VStack {
                    Text("أي فقرة تحتوي على هذه الكلمات سيتم حذفها تلقائياً أثناء السحب لضمان نظافة المحتوى.")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .padding()
                    
                    HStack {
                        TextField("أضف كلمة أو جملة محظورة...", text: $newWord)
                            .padding()
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(10)
                            .foregroundColor(.white)
                        
                        Button(action: {
                            if !newWord.isEmpty {
                                engine.blacklist.append(newWord)
                                newWord = ""
                            }
                        }) {
                            Image(systemName: "plus.circle.fill")
                                .font(.title)
                                .foregroundColor(.cyan)
                        }
                    }
                    .padding(.horizontal)
                    
                    List {
                        ForEach(engine.blacklist, id: \.self) { word in
                            HStack {
                                Text(word).foregroundColor(.white)
                                Spacer()
                                Image(systemName: "trash").foregroundColor(.red.opacity(0.7))
                                    .onTapGesture {
                                        engine.blacklist.removeAll { $0 == word }
                                    }
                            }
                            .listRowBackground(Color.white.opacity(0.05))
                        }
                        .onDelete { indexSet in
                            engine.blacklist.remove(atOffsets: indexSet)
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("قائمة الحظر الذكي")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("تم") { dismiss() }.foregroundColor(.cyan)
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

// MARK: - المكونات الفرعية

struct BrowserBarView: View {
    @ObservedObject var engine: ZeusScraperEngine
    var body: some View {
        HStack {
            TextField("رابط الرواية...", text: $engine.currentBrowserURL)
                .padding(10).background(Color.black.opacity(0.4)).cornerRadius(10)
                .foregroundColor(.white).font(.system(size: 14))
                .autocapitalization(.none).disableAutocorrection(true)
            
            Button(action: { engine.loadURL(engine.currentBrowserURL) }) {
                Image(systemName: "magnifyingglass")
                    .padding(10).background(Color.cyan.opacity(0.2)).cornerRadius(10).foregroundColor(.cyan)
            }
        }
        .padding(.horizontal).padding(.bottom, 10)
    }
}

struct ControlPanelView: View {
    @ObservedObject var engine: ZeusScraperEngine
    @Binding var startCh: String
    @Binding var isLogExpanded: Bool
    
    var body: some View {
        VStack(spacing: 15) {
            HStack {
                VStack(alignment: .leading) {
                    Text("ابدأ من رقم الرابط:").font(.caption2).foregroundColor(.gray)
                    TextField("1", text: $startCh)
                        .keyboardType(.numberPad).padding(8).frame(width: 80)
                        .background(Color.black.opacity(0.3)).cornerRadius(8).foregroundColor(.white)
                }
                Spacer()
                Button(action: { withAnimation { isLogExpanded.toggle() } }) {
                    Image(systemName: isLogExpanded ? "terminal.fill" : "terminal")
                        .foregroundColor(isLogExpanded ? .cyan : .gray)
                }
            }
            
            if !engine.isRunning {
                Button(action: { engine.analyzeCurrentPage(startCh: Int(startCh) ?? 1) }) {
                    Text("بدء الاستخراج الهجين")
                        .font(.headline).foregroundColor(.black).frame(maxWidth: .infinity).frame(height: 50)
                        .background(LinearGradient(colors: [.cyan, .blue], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .cornerRadius(15).shadow(color: .cyan.opacity(0.3), radius: 10)
                }
            } else {
                Button(action: { engine.stop() }) {
                    Text("إيقاف العملية")
                        .font(.headline).foregroundColor(.white).frame(maxWidth: .infinity).frame(height: 50)
                        .background(Color.red.opacity(0.6)).cornerRadius(15)
                }
            }
        }
        .padding(20)
    }
}

struct LogTerminalView: View {
    var logs: String
    var body: some View {
        ScrollView {
            Text(logs).font(.system(size: 10, design: .monospaced)).foregroundColor(.green)
                .padding().frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(height: 120).background(Color.black).cornerRadius(10).padding([.horizontal, .bottom])
    }
}

// MARK: - WebView Helper
struct WebViewHelper: UIViewRepresentable {
    @ObservedObject var engine: ZeusScraperEngine
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.navigationDelegate = context.coordinator
        webView.backgroundColor = .clear
        webView.isOpaque = false
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
        engine.webView = webView
        engine.loadURL(engine.currentBrowserURL)
        return webView
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(engine) }
    class Coordinator: NSObject, WKNavigationDelegate {
        var engine: ZeusScraperEngine
        init(_ engine: ZeusScraperEngine) { self.engine = engine }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { engine.handlePageFinished() }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: activityItems, applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}
