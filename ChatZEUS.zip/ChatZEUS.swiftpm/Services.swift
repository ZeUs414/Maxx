import Foundation

// MARK: - مدير الاتصال بالخادم الخلفي
final class BackendManager {
    static let shared = BackendManager()
    private init() {}
    
    private let auth = AuthManager.shared
    
    // جلب البيانات من الخادم
    func fetchData(completion: @escaping (Result<(ZeusStore, AppSettings), Error>) -> Void) {
        guard let url = URL(string: "\(auth.baseURL)/api/data") else {
            completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"])))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.addValue("Bearer \(auth.token)", forHTTPHeaderField: "Authorization")
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "No data"])))
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                
                // تحويل المحادثات
                var chats: [String: ChatDTO] = [:]
                if let chatsArray = json?["chats"] as? [[String: Any]] {
                    for chatJson in chatsArray {
                        if let chatData = try? JSONSerialization.data(withJSONObject: chatJson),
                           let chat = try? JSONDecoder().decode(ChatDTO.self, from: chatData) {
                            chats[chat.id] = chat
                        }
                    }
                }
                
                // تحويل الإعدادات
                var settings = AppSettings()
                if let settingsJson = json?["settings"] as? [String: Any],
                   let settingsData = try? JSONSerialization.data(withJSONObject: settingsJson),
                   let decodedSettings = try? JSONDecoder().decode(AppSettings.self, from: settingsData) {
                    settings = decodedSettings
                }
                
                let store = ZeusStore(chats: chats, currentChatId: nil)
                completion(.success((store, settings)))
                
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
    
    // حفظ محادثة للخادم
    func saveChat(_ chat: ChatDTO, completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "\(auth.baseURL)/api/chats") else {
            completion(false)
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("Bearer \(auth.token)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            let jsonData = try JSONEncoder().encode(chat)
            request.httpBody = jsonData
            
            URLSession.shared.dataTask(with: request) { _, response, error in
                if let error = error {
                    print("❌ خطأ في حفظ المحادثة: \(error)")
                    completion(false)
                    return
                }
                
                if let httpResponse = response as? HTTPURLResponse,
                   httpResponse.statusCode == 200 || httpResponse.statusCode == 201 {
                    completion(true)
                } else {
                    completion(false)
                }
            }.resume()
            
        } catch {
            print("❌ خطأ في ترميز المحادثة: \(error)")
            completion(false)
        }
    }
    
    // حفظ الإعدادات للخادم
    func saveSettings(_ settings: AppSettings, completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "\(auth.baseURL)/api/settings") else {
            completion(false)
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.addValue("Bearer \(auth.token)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            let jsonData = try JSONEncoder().encode(settings)
            request.httpBody = jsonData
            
            URLSession.shared.dataTask(with: request) { _, response, error in
                if let error = error {
                    print("❌ خطأ في حفظ الإعدادات: \(error)")
                    completion(false)
                    return
                }
                
                if let httpResponse = response as? HTTPURLResponse,
                   httpResponse.statusCode == 200 {
                    completion(true)
                } else {
                    completion(false)
                }
            }.resume()
            
        } catch {
            print("❌ خطأ في ترميز الإعدادات: \(error)")
            completion(false)
        }
    }
    
    // حذف محادثة من الخادم
    func deleteChat(_ chatId: String, completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "\(auth.baseURL)/api/chats/\(chatId)") else {
            completion(false)
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        request.addValue("Bearer \(auth.token)", forHTTPHeaderField: "Authorization")
        
        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                print("❌ خطأ في حذف المحادثة: \(error)")
                completion(false)
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse,
               httpResponse.statusCode == 200 {
                completion(true)
            } else {
                completion(false)
            }
        }.resume()
    }
}

// MARK: - تخزين محادثات ZeusStore في ملف JSON واحد
final class ZeusPersistence {
    static let shared = ZeusPersistence(); private init() {}
    private let fileURL: URL = {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return docs.appendingPathComponent("zeus_store_v1.json")
    }()
    
    func save(store: ZeusStore) {
        do {
            let data = try JSONEncoder().encode(store)
            try data.write(to: fileURL, options: [.atomic])
        } catch {
            print("❌ فشل حفظ zeus_store: \(error)")
        }
    }
    
    func load() -> ZeusStore? {
        guard FileManager.default.fileExists(atPath: fileURL.path) else { return nil }
        do {
            let data = try Data(contentsOf: fileURL)
            return try JSONDecoder().decode(ZeusStore.self, from: data)
        } catch {
            print("❌ فشل قراءة zeus_store: \(error)")
            return nil
        }
    }
}

// MARK: - تخزين/قراءة AppSettings من ملف JSON
final class SettingsPersistence {
    static let shared = SettingsPersistence(); private init() {}
    
    private var url: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return docs.appendingPathComponent("zeus_settings_v1.json")
    }
    
    func load() -> AppSettings {
        do {
            let data = try Data(contentsOf: url)
            return try JSONDecoder().decode(AppSettings.self, from: data)
        } catch {
            return AppSettings() // افتراضي
        }
    }
    
    func save(_ s: AppSettings) {
        do {
            let data = try JSONEncoder().encode(s)
            try data.write(to: url, options: [.atomic])
        } catch {
            print("❌ فشل حفظ الإعدادات: \(error)")
        }
    }
}

// ======================================================================
// MARK: - APIManager موحّد (يدعم Gemini / OpenRouter / Custom + مفاتيح متعددة)
// ======================================================================

final class APIManager {
    static let shared = APIManager(); private init() {}
    
    // فهارس Round-Robin لكل "سطل" مفاتيح
    private var rrIndex: [String: Int] = [:]
    
    // تنقية رسائل المحادثة قبل الإرسال (منع عناصر الواجهة/الفارغ)
    // ⬅️ جعلناها داخلية (ليست private) لكي يستخدمها StreamingAPI.swift
    func sanitizedMessages(_ messages: [MessageDTO]) -> [MessageDTO] {
        let blockedExact: Set<String> = [
            "جاري الكتابة...", "جاري الكتابة...", "جارٍ الكتابة...", "جارٍ الكتابة...",
            "typing...", "typing...", "...", "..."
        ]
        return messages.filter { msg in
            let t = msg.content.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !t.isEmpty else { return false }
            if msg.role == .assistant {
                if blockedExact.contains(t) { return false }
                if t.contains("جاري الكتابة") || t.contains("جارٍ الكتابة") || t.lowercased().contains("typing") {
                    return false
                }
            }
            return true
        }
    }
    
    // اختيار المفتاح التالي بحسب الاستراتيجية
    // ⬅️ جعلناها داخلية (ليست private) لكي يستخدمها StreamingAPI.swift
    func nextKey(from keys: [APIKeyEntry],
                 strategy: APIKeyRetryStrategy,
                 bucket: String) -> String? {
        let active = keys.filter { $0.status == .active && !$0.key.trimmingCharacters(in: .whitespaces).isEmpty }
        guard !active.isEmpty else { return nil }
        switch strategy {
        case .sequential:
            return active.first?.key
        case .roundRobin:
            let idx = rrIndex[bucket, default: 0] % active.count
            rrIndex[bucket] = idx + 1
            return active[idx].key
        }
    }
    
    // نقطة الدخول العامة (استجابة غير متدفقة)
    func sendMessage(from chat: ChatDTO,
                     settings: AppSettings,
                     completion: @escaping (String) -> Void) {
        // أنشئ نسخة مُصفّاة من الرسائل
        let cleanChat = ChatDTO(
            id: chat.id,
            title: chat.title,
            messages: sanitizedMessages(chat.messages),
            createdAt: chat.createdAt,
            updatedAt: chat.updatedAt,
            order: chat.order
        )
        
        switch settings.provider {
        case .gemini:
            sendToGemini(chat: cleanChat, settings: settings, completion: completion)
        case .openrouter:
            sendToOpenRouter(chat: cleanChat, settings: settings, completion: completion)
        case .custom:
            sendToCustomProvider(chat: cleanChat, settings: settings, completion: completion)
        }
    }
}

// =======================================================
// MARK: - OpenRouter (تجميعة جسم الطلب غير المتدفّق)
// =======================================================

private extension APIManager {
    func openrouterMessages(for chat: ChatDTO,
                            customPrompt: String?) -> [[String: Any]] {
        var msgs: [[String: Any]] = []
        if let p = customPrompt, !p.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            msgs.append(["role": "system", "content": p])
        }
        for m in chat.messages {
            var text = m.content
            for a in m.attachments {
                if a.dataType == "text", let t = a.content {
                    text += "\n\n--- محتوى الملف: \(a.name) ---\n\(t)\n--- نهاية الملف ---"
                } else if a.dataType == "image" {
                    // بعض النماذج لا تدعم الصور مباشرة في chat/completions؛ نضيف إشارة
                    text += "\n\n[صورة مرفقة: \(a.name)]"
                }
            }
            msgs.append(["role": (m.role == .user ? "user" : "assistant"), "content": text])
        }
        return msgs
    }
    
    func sendToOpenRouter(chat: ChatDTO,
                          settings: AppSettings,
                          completion: @escaping (String) -> Void) {
        guard let key = nextKey(from: settings.openrouterApiKeys,
                                strategy: settings.apiKeyRetryStrategy,
                                bucket: "openrouter") else {
            completion("❌ لا توجد مفاتيح OpenRouter نشطة")
            return
        }
        
        let body: [String: Any] = [
            "model": settings.model,
            "messages": openrouterMessages(for: chat, customPrompt: settings.customPrompt),
            "temperature": settings.temperature,
            "stream": false,
            "max_tokens": 4096
        ]
        
        var req = URLRequest(url: URL(string: "https://openrouter.ai/api/v1/chat/completions")!)
        req.httpMethod = "POST"
        req.addValue("application/json", forHTTPHeaderField: "Content-Type")
        req.addValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: req) { data, _, _ in
            guard let data = data else {
                completion("❌ لا توجد بيانات من OpenRouter")
                return
            }
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let choices = json["choices"] as? [[String: Any]],
               let msg = choices.first?["message"] as? [String: Any],
               let reply = msg["content"] as? String {
                completion(reply)
            } else {
                completion("❌ تعذّر تحليل استجابة OpenRouter")
            }
        }.resume()
    }
}

// =======================================================
// MARK: - مزوّد مخصّص (توافق OpenAI-style)
//  ⬅️ أزلنا private عن الـ extension لأن StreamingAPI يحتاج resolveCustomProvider
// =======================================================

extension APIManager {
    func resolveCustomProvider(settings: AppSettings) -> CustomProvider? {
        // اختر أول مزوّد مخصّص أو يمكنك تحسين المنطق للبحث حسب model/providerId
        return settings.customProviders.first
    }
    
    func sendToCustomProvider(chat: ChatDTO,
                              settings: AppSettings,
                              completion: @escaping (String) -> Void) {
        guard let provider = resolveCustomProvider(settings: settings) else {
            completion("❌ لا يوجد مزوّد مخصّص مُعرّف")
            return
        }
        guard let key = nextKey(from: provider.apiKeys,
                                strategy: settings.apiKeyRetryStrategy,
                                bucket: provider.id) else {
            completion("❌ لا توجد مفاتيح للمزوّد المخصّص")
            return
        }
        
        // نفترض توافق /chat/completions
        let body: [String: Any] = [
            "model": settings.model,
            "messages": openrouterMessages(for: chat, customPrompt: settings.customPrompt),
            "temperature": settings.temperature
        ]
        
        var req = URLRequest(url: provider.baseUrl.appendingPathComponent("chat/completions"))
        req.httpMethod = "POST"
        req.addValue("application/json", forHTTPHeaderField: "Content-Type")
        req.addValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: req) { data, _, _ in
            guard let data = data else {
                completion("❌ لا توجد بيانات من المزود المخصّص")
                return
            }
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let choices = json["choices"] as? [[String: Any]],
               let msg = choices.first?["message"] as? [String: Any],
               let reply = msg["content"] as? String {
                completion(reply)
            } else {
                completion("❌ تعذّر تحليل استجابة المزوّد المخصّص")
            }
        }.resume()
    }
}

// =======================================================
// MARK: - Gemini (نص + صور Base64 عبر inline_data)
//  ⬅️ أزلنا private عن الـ extension لأن StreamingAPI يحتاج geminiBody
// =======================================================

extension APIManager {
    func geminiBody(for chat: ChatDTO,
                    model: String,
                    temperature: Double,
                    customPrompt: String?,
                    enableWebSearch: Bool = false,
                    webSearchDynamic: Bool = true) -> [String: Any] {
        var contents: [[String: Any]] = []
        
        // برومبت مخصّص (إن وُجد) كبداية للحوار
        if let p = customPrompt, !p.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            contents.append(["role": "user", "parts": [["text": p]]])
            contents.append(["role": "model", "parts": [["text": "مفهوم، سأتبع هذه التعليمات."]]])
        }
        
        for m in chat.messages {
            var parts: [[String: Any]] = []
            if !m.content.isEmpty { parts.append(["text": m.content]) }
            
            // المرفقات: نصوص تُلحق كنص؛ صور تُرسل inline_data (Base64)
            for a in m.attachments {
                if a.dataType == "image", let b64 = a.content, let mime = a.type {
                    parts.append(["inline_data": ["mime_type": mime, "data": b64]])
                } else if a.dataType == "text", let t = a.content {
                    parts.append(["text": "\n\n--- محتوى الملف: \(a.name) ---\n\(t)\n--- نهاية الملف ---"])
                }
            }
            contents.append(["role": (m.role == .user ? "user" : "model"), "parts": parts])
        }
        
        var body: [String: Any] = [
            "contents": contents,
            "generationConfig": [
                "temperature": temperature,
                "maxOutputTokens": 8192
            ]
        ]
        
        // إضافة أدوات البحث المحسنة (مثل الموقع تماماً)
        if enableWebSearch {
            let dynThreshold = webSearchDynamic ? 0.3 : 0.6
            
            // تحديد النماذج المدعومة
            let legacyModels = ["gemini-2.5-flash", "gemini-1.5-pro", "gemini-2.5-pro"]
            let isLegacyModel = legacyModels.contains(model)
            
            if isLegacyModel {
                // استخدام googleSearchRetrieval للنماذج القديمة (مثل الموقع)
                body["tools"] = [[
                    "googleSearchRetrieval": [
                        "dynamicRetrievalConfig": [
                            "mode": "MODE_DYNAMIC",
                            "dynamicThreshold": dynThreshold
                        ]
                    ]
                ]]
            } else {
                // استخدام googleSearch للنماذج الحديثة
                body["tools"] = [[
                    "googleSearch": [:]
                ]]
            }
            
            print("🔍 البحث مفعّل مع threshold: \(dynThreshold) للموديل: \(model)")
        }
        
        return body
    }
    
    func sendToGemini(chat: ChatDTO,
                      settings: AppSettings,
                      completion: @escaping (String) -> Void) {
        guard let key = nextKey(from: settings.geminiApiKeys,
                                strategy: settings.apiKeyRetryStrategy,
                                bucket: "gemini") else {
            completion("❌ لا توجد مفاتيح Gemini نشطة")
            return
        }
        
        let body = geminiBody(for: chat,
                              model: settings.model,
                              temperature: settings.temperature,
                              customPrompt: settings.customPrompt,
                              enableWebSearch: settings.enableWebSearch,
                              webSearchDynamic: settings.webSearchDynamic)
        
        // بدايةً بدون بث (يمكن تحويلها لاحقاً إلى SSE)
        let url = URL(string: "https://generativelanguage.googleapis.com/v1beta/models/\(settings.model):generateContent?key=\(key)")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.addValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: req) { data, _, _ in
            guard let data = data else {
                completion("❌ لا توجد بيانات من Gemini")
                return
            }
            
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                // استخراج النص من الرد مع دعم مصادر البحث
                let responseText = APIManager.extractGeminiResponse(from: json)
                completion(responseText)
            } else {
                completion("❌ تعذّر تحليل استجابة Gemini")
            }
        }.resume()
    }
    
    // دالة مساعدة لاستخراج الرد مع مصادر البحث
    private static func extractGeminiResponse(from json: [String: Any]) -> String {
        guard let candidates = json["candidates"] as? [[String: Any]],
              let firstCandidate = candidates.first,
              let content = firstCandidate["content"] as? [String: Any],
              let parts = content["parts"] as? [[String: Any]] else {
            return "❌ تعذّر تحليل استجابة Gemini"
        }
        
        var responseText = ""
        
        // استخراج النص الأساسي
        for part in parts {
            if let text = part["text"] as? String {
                responseText += text
            }
        }
        
        // إضافة مصادر البحث إن وُجدت
        if let groundingMetadata = firstCandidate["groundingMetadata"] as? [String: Any],
           let webSearchQueries = groundingMetadata["webSearchQueries"] as? [String],
           let searchEntryPoints = groundingMetadata["searchEntryPoints"] as? [[String: Any]] {
            
            responseText += "\n\n📚 **المصادر:**\n"
            
            // إضافة استعلامات البحث
            if !webSearchQueries.isEmpty {
                responseText += "\n**تم البحث عن:** " + webSearchQueries.joined(separator: "، ") + "\n"
            }
            
            // إضافة المصادر
            for (index, entry) in searchEntryPoints.enumerated() {
                if let renderedContent = entry["renderedContent"] as? String {
                    responseText += "\n\(index + 1). \(renderedContent)"
                }
            }
        }
        
        return responseText.isEmpty ? "❌ لا توجد استجابة من Gemini" : responseText
    }
    // دالة مساعدة لاستخراج الرد مع مصادر البحث من JSON
    static func extractGeminiResponseWithSources(from json: [String: Any]) -> String {
        guard let candidates = json["candidates"] as? [[String: Any]],
              let firstCandidate = candidates.first,
              let content = firstCandidate["content"] as? [String: Any],
              let parts = content["parts"] as? [[String: Any]] else {
            return "❌ تعذّر تحليل استجابة Gemini"
        }
        
        var responseText = ""
        
        // استخراج النص الأساسي
        for part in parts {
            if let text = part["text"] as? String {
                responseText += text
            }
        }
        
        // استخراج المصادر بنفس طريقة الموقع
        if let groundingMetadata = firstCandidate["groundingMetadata"] as? [String: Any] {
            print("📊 Grounding metadata found: \(groundingMetadata)")
            
            var sources: [String] = []
            
            // الطريقة الأولى: citations (مثل الموقع)
            if let citations = groundingMetadata["citations"] as? [[String: Any]] {
                print("📚 Found \(citations.count) citations")
                for (index, citation) in citations.enumerated() {
                    let uri = citation["uri"] as? String ?? 
                    citation["sourceUri"] as? String ?? 
                    (citation["source"] as? [String: Any])?["uri"] as? String
                    
                    var title = citation["title"] as? String ?? 
                    citation["sourceTitle"] as? String ?? 
                    (citation["source"] as? [String: Any])?["title"] as? String
                    
                    if let cleanUri = uri, cleanUri.hasPrefix("http") {
                        // تنظيف العنوان
                        if let t = title, t.count > 80 {
                            title = String(t.prefix(77)) + "..."
                        }
                        if title == nil { title = "مصدر \(index + 1)" }
                        
                        let cleanUrl = extractRealUrlFromGoogleRedirect(cleanUri)
                        sources.append("- [\(title!)](\(cleanUrl))")
                    }
                }
            }
            
            // الطريقة الثانية: groundingChunks (احتياطي)
            if sources.isEmpty, let groundingChunks = groundingMetadata["groundingChunks"] as? [[String: Any]] {
                print("🌐 Found \(groundingChunks.count) grounding chunks")
                for (index, chunk) in groundingChunks.enumerated() {
                    let uri = (chunk["web"] as? [String: Any])?["uri"] as? String ??
                    (chunk["source"] as? [String: Any])?["uri"] as? String
                    
                    var title = (chunk["web"] as? [String: Any])?["title"] as? String ??
                    chunk["title"] as? String ??
                    (chunk["source"] as? [String: Any])?["title"] as? String
                    
                    if let cleanUri = uri, cleanUri.hasPrefix("http") {
                        if let t = title, t.count > 80 {
                            title = String(t.prefix(77)) + "..."
                        }
                        if title == nil { title = "مصدر \(index + 1)" }
                        
                        let cleanUrl = extractRealUrlFromGoogleRedirect(cleanUri)
                        sources.append("- [\(title!)](\(cleanUrl))")
                    }
                }
            }
            
            // الطريقة الثالثة: searchEntryPoints (احتياطي ثالث)
            if sources.isEmpty, let searchEntryPoints = groundingMetadata["searchEntryPoints"] as? [[String: Any]] {
                print("🎯 Found search entry points")
                for (index, entry) in searchEntryPoints.enumerated() {
                    if let renderedContent = entry["renderedContent"] as? String,
                       let url = entry["url"] as? String {
                        let title = entry["title"] as? String ?? "نتيجة البحث \(index + 1)"
                        let cleanUrl = extractRealUrlFromGoogleRedirect(url)
                        sources.append("- [\(title)](\(cleanUrl))")
                    }
                }
            }
            
            // إضافة المصادر للنص
            if !sources.isEmpty {
                print("✅ Found \(sources.count) sources")
                responseText += "\n\n**🔍 المصادر:**\n" + sources.joined(separator: "\n")
            } else {
                print("⚠️ No sources found")
                if !groundingMetadata.isEmpty {
                    print("🔍 Available metadata keys: \(Array(groundingMetadata.keys))")
                }
            }
        }
        
        return responseText.isEmpty ? "❌ لا توجد استجابة من Gemini" : responseText
    }
    
    // دالة مساعدة لاستخراج مصادر البحث كـ GroundingMetadata
    static func extractGroundingMetadata(from groundingMetadata: [String: Any]) -> GroundingMetadata {
        var searchQueries: [String] = []
        var sources: [GroundingSource] = []
        
        // استخراج استعلامات البحث
        if let webSearchQueries = groundingMetadata["webSearchQueries"] as? [String] {
            searchQueries = webSearchQueries
        }
        
        // الطريقة الجديدة: استخراج من groundingSupports أولاً (الأحدث)
        if let groundingSupports = groundingMetadata["groundingSupports"] as? [[String: Any]] {
            for support in groundingSupports {
                if let groundingSources = support["groundingSources"] as? [[String: Any]] {
                    for sourceData in groundingSources {
                        if let title = sourceData["title"] as? String,
                           let uri = sourceData["uri"] as? String {
                            let cleanUrl = extractRealUrlFromGoogleRedirect(uri)
                            sources.append(GroundingSource(title: title, url: cleanUrl))
                        }
                    }
                }
            }
        }
        
        // استخراج المصادر من searchEntryPoints
        if sources.isEmpty, let searchEntryPoints = groundingMetadata["searchEntryPoints"] as? [[String: Any]] {
            for entry in searchEntryPoints {
                if let renderedContent = entry["renderedContent"] as? String {
                    let (title, url) = parseRenderedContent(renderedContent)
                    if !title.isEmpty && !url.isEmpty {
                        let cleanUrl = extractRealUrlFromGoogleRedirect(url)
                        sources.append(GroundingSource(title: title, url: cleanUrl))
                    }
                }
            }
        }
        
        // إذا لم نجد مصادر، جرب groundingChunks (للتوافق مع النسخ القديمة)
        if sources.isEmpty, let groundingChunks = groundingMetadata["groundingChunks"] as? [[String: Any]] {
            for chunk in groundingChunks {
                if let web = chunk["web"] as? [String: Any],
                   let title = web["title"] as? String,
                   let uri = web["uri"] as? String {
                    let cleanUrl = extractRealUrlFromGoogleRedirect(uri)
                    sources.append(GroundingSource(title: title, url: cleanUrl))
                }
            }
        }
        
        return GroundingMetadata(searchQueries: searchQueries, sources: sources)
    }
    
    // دالة مساعدة لاستخراج العنوان والرابط من renderedContent
    private static func parseRenderedContent(_ content: String) -> (title: String, url: String) {
        // البحث عن الرابط داخل الأقواس المربعة [العنوان](الرابط)
        let markdownPattern = #"\[([^\]]+)\]\(([^)]+)\)"#
        if let regex = try? NSRegularExpression(pattern: markdownPattern),
           let match = regex.firstMatch(in: content, range: NSRange(content.startIndex..., in: content)) {
            let titleRange = Range(match.range(at: 1), in: content)!
            let urlRange = Range(match.range(at: 2), in: content)!
            let title = String(content[titleRange])
            let url = String(content[urlRange])
            return (title, extractRealUrlFromGoogleRedirect(url))
        }
        
        // البحث عن رابط مباشر مع عنوان منفصل
        let directLinkPattern = #"^(.+?)\s+(https?://[^\s\]]+)"#
        if let regex = try? NSRegularExpression(pattern: directLinkPattern),
           let match = regex.firstMatch(in: content, range: NSRange(content.startIndex..., in: content)) {
            let titleRange = Range(match.range(at: 1), in: content)!
            let urlRange = Range(match.range(at: 2), in: content)!
            let title = String(content[titleRange]).trimmingCharacters(in: .whitespacesAndNewlines)
            let url = String(content[urlRange])
            return (title, extractRealUrlFromGoogleRedirect(url))
        }
        
        // إذا لم نجد نمط markdown، نبحث عن أي URL في النص
        let urlPattern = #"https?://[^\s\]]+"#
        if let urlRegex = try? NSRegularExpression(pattern: urlPattern),
           let urlMatch = urlRegex.firstMatch(in: content, range: NSRange(content.startIndex..., in: content)) {
            let urlRange = Range(urlMatch.range, in: content)!
            let url = String(content[urlRange])
            // استخدم أول جزء من النص كعنوان
            let title = content.replacingOccurrences(of: url, with: "")
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let finalTitle = title.isEmpty ? "مصدر" : title
            return (finalTitle, extractRealUrlFromGoogleRedirect(url))
        }
        
        return ("", "")
    }
    
    // دالة لتنظيف URLs المُعاد توجيهها من Google
    private static func cleanGoogleRedirectUrl(_ url: String) -> String {
        // إذا كان الرابط من Google redirect، استخرج الرابط الحقيقي
        if url.contains("google.com/url?") {
            if let urlComponents = URLComponents(string: url),
               let queryItems = urlComponents.queryItems,
               let actualUrl = queryItems.first(where: { $0.name == "url" })?.value {
                return actualUrl
            }
        }
        
        // إذا كان من vertexaisearch أو مشابه، حاول البحث عن معامل redirect
        if url.contains("vertexaisearch.cloud.google.com") || url.contains("redirect") {
            if let urlComponents = URLComponents(string: url),
               let queryItems = urlComponents.queryItems {
                // ابحث عن معاملات مختلفة قد تحتوي على الرابط الحقيقي
                for item in queryItems {
                    if ["url", "target", "redirect", "link"].contains(item.name.lowercased()),
                       let value = item.value,
                       value.hasPrefix("http") {
                        return value
                    }
                }
            }
        }
        
        return url
    }
    
    // دالة محسّنة لفك تشفير روابط Google (مع طباعة تشخيصية)
    private static func extractRealUrlFromGoogleRedirect(_ url: String) -> String {
        print("🔗 معالجة الرابط: \(url)")
        
        // فحص شامل لجميع أنواع روابط Google
        if url.contains("vertexaisearch.cloud.google.com") ||
            url.contains("google.com/url") ||
            url.contains("googleusercontent.com") ||
            url.contains("scholar.google.com") ||
            url.contains("books.google.com") {
            
            if let urlComponents = URLComponents(string: url),
               let queryItems = urlComponents.queryItems {
                
                // قائمة شاملة من معاملات الإعادة التوجيه المحتملة
                let redirectParams = ["url", "u", "q", "target", "redirect", "dest", "destination", "link", "href"]
                
                for param in redirectParams {
                    if let value = queryItems.first(where: { $0.name.lowercased() == param })?.value?.removingPercentEncoding,
                       value.hasPrefix("http") && !value.contains("google.com") {
                        print("✅ تم استخراج الرابط من معامل \(param): \(value)")
                        return value
                    }
                }
                
                // محاولة أخرى في fragment
                if let fragment = urlComponents.fragment,
                   let fragmentUrl = extractUrlFromString(fragment),
                   !fragmentUrl.contains("google.com") {
                    print("✅ تم استخراج الرابط من fragment: \(fragmentUrl)")
                    return fragmentUrl
                }
            }
        }
        
        // إذا كان الرابط عادي ولا يحتوي على google
        if url.hasPrefix("http") && !url.contains("google.com") {
            print("✅ رابط مباشر: \(url)")
            return url
        }
        
        print("⚠️ لم يتم فك تشفير الرابط: \(url)")
        return url
    }
    
    // دالة مساعدة لاستخراج URL من النص
    private static func extractUrlFromString(_ text: String) -> String? {
        let urlPattern = #"https?://[^\s\])]+"#
        if let regex = try? NSRegularExpression(pattern: urlPattern),
           let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) {
            let range = Range(match.range, in: text)!
            return String(text[range])
        }
        return nil
    }
    
    // نسخة للتوافق مع الكود القديم (ترجع نص فارغ لأننا لا نريد نص إضافي)
    static func extractGroundingSources(from groundingMetadata: [String: Any]) -> String {
        return "" // لا نريد نص إضافي، المصادر ستظهر كزر
    }
    
    // دالة احتياطية للحصول على استجابة فورية من Gemini بدون بث (تم نقلها لتكون جزءًا من APIManager)
    // دالة احتياطية للحصول على استجابة من الخادم الخلفي بدون بث
    func sendToGeminiDirect(chat: ChatDTO,
                            settings: AppSettings,
                            completion: @escaping (String) -> Void) {
        let auth = AuthManager.shared
        guard let url = URL(string: "\(auth.baseURL)/api/chat") else {
            completion("❌ عنوان الخادم غير صحيح")
            return
        }
        
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.addValue("Bearer \(auth.token)", forHTTPHeaderField: "Authorization")
        req.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // تجهيز البيانات للإرسال
        let payload: [String: Any] = [
            "chatHistory": chat.messages.map { msg in
                [
                    "role": msg.role.rawValue,
                    "content": msg.content
                ]
            },
            "settings": [
                "provider": settings.provider.rawValue,
                "model": settings.model,
                "temperature": settings.temperature,
                "customPrompt": settings.customPrompt,
                "enableWebBrowsing": settings.enableWebSearch,
                "browsingMode": "gemini",
                "showSources": true,
                "dynamicThreshold": settings.webSearchDynamic ? 0.3 : 0.6,
                "geminiApiKeys": settings.geminiApiKeys.map { ["key": $0.key, "status": $0.status.rawValue] },
                "openrouterApiKeys": settings.openrouterApiKeys.map { ["key": $0.key, "status": $0.status.rawValue] },
                "apiKeyRetryStrategy": settings.apiKeyRetryStrategy.rawValue
            ]
        ]
        
        do {
            req.httpBody = try JSONSerialization.data(withJSONObject: payload)
        } catch {
            completion("❌ فشل في تحضير الطلب")
            return
        }
        
        URLSession.shared.dataTask(with: req) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion("❌ خطأ في الشبكة: \(error.localizedDescription)")
                    return
                }
                
                guard let data = data else {
                    completion("❌ لا توجد بيانات من الخادم")
                    return
                }
                
                if let responseText = String(data: data, encoding: .utf8) {
                    print("📡 Server Response: \(responseText)")
                    completion(responseText)
                } else {
                    completion("❌ تعذّر قراءة استجابة الخادم")
                }
            }
        }.resume()
    }
}
