import Foundation

// ضع هذا أعلى الملف أو أسفله
enum StreamEvent {
    case token(String)
    case groundingData(GroundingMetadata)
    case done
    case error(String)
}

extension APIManager {
    /// نقطة دخول للبث الحقيقي
    func sendMessageStream(
        from chat: ChatDTO,
        settings: AppSettings,
        onEvent: @escaping (StreamEvent) -> Void
    ) {
        let cleanChat = ChatDTO(
            id: chat.id,
            title: chat.title,
            messages: sanitizedMessages(chat.messages),
            createdAt: chat.createdAt,
            updatedAt: chat.updatedAt,
            order: chat.order
        )
        
        switch settings.provider {
        case .gemini:
            streamGeminiRealTime(chat: cleanChat, settings: settings, onEvent: onEvent)
            
        case .openrouter:
            streamOpenAIStyle(
                url: URL(string: "https://openrouter.ai/api/v1/chat/completions")!,
                apiKey: nextKey(from: settings.openrouterApiKeys,
                                strategy: settings.apiKeyRetryStrategy,
                                bucket: "openrouter"),
                body: openAIStyleBody(for: cleanChat,
                                      model: settings.model,
                                      temperature: settings.temperature,
                                      customPrompt: settings.customPrompt,
                                      stream: true),
                extraHeaders: [
                    "HTTP-Referer": "https://chatzeus.app",
                    "X-Title": "ChatZEUS"
                ],
                onEvent: onEvent
            )
            
        case .custom:
            guard let p = resolveCustomProvider(settings: settings) else {
                onEvent(.error("❌ لم يتم ضبط مزوّد مخصّص")); return
            }
            streamOpenAIStyle(
                url: p.baseUrl.appendingPathComponent("chat/completions"),
                apiKey: nextKey(from: p.apiKeys,
                                strategy: settings.apiKeyRetryStrategy,
                                bucket: p.id),
                body: openAIStyleBody(for: cleanChat,
                                      model: settings.model,
                                      temperature: settings.temperature,
                                      customPrompt: settings.customPrompt,
                                      stream: true),
                extraHeaders: [:],
                onEvent: onEvent
            )
        }
    }
}

// MARK: - Gemini Real-time Streaming
extension APIManager {
    func streamGeminiRealTime(
        chat: ChatDTO,
        settings: AppSettings,
        onEvent: @escaping (StreamEvent) -> Void
    ) {
        let auth = AuthManager.shared
        guard let url = URL(string: "\(auth.baseURL)/api/chat") else {
            onEvent(.error("❌ عنوان الخادم غير صحيح"))
            return
        }
        
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("Bearer \(auth.token)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // تجهيز البيانات للإرسال
        let payload: [String: Any] = [
            "chatHistory": chat.messages.map { msg in
                [
                    "role": msg.role.rawValue,
                    "content": msg.content,
                    "attachments": msg.attachments.map { att in
                        [
                            "name": att.name,
                            "type": att.type ?? "",
                            "dataType": att.dataType ?? "",
                            "content": att.content ?? ""
                        ]
                    }
                ]
            },
            "settings": [
                "provider": settings.provider.rawValue,
                "model": settings.model,
                "temperature": settings.temperature,
                "customPrompt": settings.customPrompt,
                "enableWebBrowsing": settings.enableWebSearch,
                "browsingMode": "gemini",
                "showSources": true,
                "dynamicThreshold": settings.webSearchDynamic ? 0.3 : 0.6,
                "geminiApiKeys": settings.geminiApiKeys.map { ["key": $0.key, "status": $0.status.rawValue] },
                "openrouterApiKeys": settings.openrouterApiKeys.map { ["key": $0.key, "status": $0.status.rawValue] },
                "apiKeyRetryStrategy": settings.apiKeyRetryStrategy.rawValue
            ]
        ]
        
        do {
            req.httpBody = try JSONSerialization.data(withJSONObject: payload)
        } catch {
            onEvent(.error("❌ فشل في تحضير البيانات"))
            return
        }
        
        // إنشاء URLSession مع configuration مخصص
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 60.0
        config.timeoutIntervalForResource = 120.0
        
        // التعديل هنا: استخدام الاسم الكامل للكلاس المتداخل
        let streamDelegate = GeminiStreamDelegate.ServerStreamDelegate(onEvent: onEvent)
        let streamSession = URLSession(configuration: config, delegate: streamDelegate, delegateQueue: nil)
        let streamTask = streamSession.dataTask(with: req)
        
        streamTask.resume()
    }
    // تم تغيير مستوى الحماية إلى 'fileprivate' لتمكين الوصول من نفس الملف
    // أو يمكن جعله 'public' إذا كان يحتاج للوصول من ملفات أخرى
    fileprivate static func extractGroundingSourcess(from groundingData: [String: Any]) -> String {
        guard let groundingSources = groundingData["groundingSources"] as? [[String: Any]] else {
            return ""
        }
        
        let sourcesText = groundingSources.compactMap { source in
            guard let uri = source["uri"] as? String,
                  let title = source["title"] as? String else {
                return nil
            }
            return "[\(title)](\(uri))"
        }.joined(separator: ", ")
        
        return sourcesText.isEmpty ? "" : "\n\nSources: " + sourcesText
    }
}

// MARK: - Custom URLSessionDataDelegate for Gemini Streaming
class GeminiStreamDelegate: NSObject, URLSessionDataDelegate {
    
    private let onEvent: (StreamEvent) -> Void
    private var buffer = ""
    
    init(onEvent: @escaping (StreamEvent) -> Void) {
        self.onEvent = onEvent
        super.init()
    }
    
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard let chunk = String(data: data, encoding: .utf8) else { return }
        
        buffer += chunk
        
        // تحليل البيانات المتراكمة
        let lines = buffer.components(separatedBy: .newlines)
        
        // احتفظ بالسطر الأخير في البافر إذا كان غير مكتمل
        buffer = lines.last ?? ""
        
        // معالجة الأسطر المكتملة
        for line in lines.dropLast() {
            processSSELine(line)
        }
    }
    
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didCompleteWithError error: Error?) {
        DispatchQueue.main.async {
            if let error = error {
                self.onEvent(.error("❌ خطأ في الشبكة: \(error.localizedDescription)"))
            } else {
                // معالجة آخر سطر في البافر
                if !self.buffer.isEmpty {
                    self.processSSELine(self.buffer)
                }
                // لا حاجة لإرسال .done هنا لأنه سيتم إرساله من processSSELine
            }
        }
    }
    
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        if let httpResponse = response as? HTTPURLResponse,
           httpResponse.statusCode != 200 {
            DispatchQueue.main.async {
                self.onEvent(.error("❌ خطأ من الخادم: \(httpResponse.statusCode)"))
            }
            completionHandler(.cancel)
        } else {
            completionHandler(.allow)
        }
    }
    
    private func processSSELine(_ line: String) {
        let trimmedLine = line.trimmingCharacters(in: .whitespaces)
        
        // تجاهل الأسطر الفارغة والتعليقات
        if trimmedLine.isEmpty || trimmedLine.hasPrefix(":") {
            return
        }
        
        // معالجة أسطر البيانات
        if trimmedLine.hasPrefix("data: ") {
            let jsonString = String(trimmedLine.dropFirst(6))
            
            // تجاهل إشارات النهاية
            if jsonString == "[DONE]" || jsonString.isEmpty {
                return
            }
            
            // تحليل JSON
            guard let jsonData = jsonString.data(using: .utf8),
                  let json = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any] else {
                return
            }
            
            // استخراج النص وإرساله فوراً
            if let candidates = json["candidates"] as? [[String: Any]] {
                for candidate in candidates {
                    if let content = candidate["content"] as? [String: Any],
                       let parts = content["parts"] as? [[String: Any]] {
                        for part in parts {
                            if let text = part["text"] as? String, !text.isEmpty {
                                DispatchQueue.main.async {
                                    self.onEvent(.token(text))
                                }
                            }
                        }
                    }
                    
                    
                    
                    // فحص انتهاء التوليد
                    if let finishReason = candidate["finishReason"] as? String,
                       finishReason == "STOP" {
                        // معالجة المصادر قبل إنهاء البث
                        if let groundingMetadata = candidate["groundingMetadata"] as? [String: Any] {
                            let metadata = APIManager.extractGroundingMetadata(from: groundingMetadata)
                            if metadata.hasGrounding {
                                DispatchQueue.main.async {
                                    self.onEvent(.groundingData(metadata))
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                        self.onEvent(.done)
                                    }
                                }
                                return
                            }
                        }
                        
                        DispatchQueue.main.async {
                            self.onEvent(.done)
                        }
                        return
                    }
                }
            }
            
            // فحص الأخطاء
            if let error = json["error"] as? [String: Any],
               let message = error["message"] as? String {
                DispatchQueue.main.async {
                    self.onEvent(.error("❌ خطأ من Gemini: \(message)"))
                }
                return
            }
        }
    }
    
    
    // MARK: - Custom URLSessionDataDelegate للبث من الخادم الخلفي
    class ServerStreamDelegate: NSObject, URLSessionDataDelegate {
        
        private let onEvent: (StreamEvent) -> Void
        private var buffer = ""
        
        init(onEvent: @escaping (StreamEvent) -> Void) {
            self.onEvent = onEvent
            super.init()
        }
        
        func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
            guard let chunk = String(data: data, encoding: .utf8) else { return }
            
            buffer += chunk
            
            // معالجة البيانات المباشرة
            let lines = buffer.components(separatedBy: .newlines)
            buffer = lines.last ?? ""
            
            for line in lines.dropLast() {
                if !line.trimmingCharacters(in: .whitespaces).isEmpty {
                    DispatchQueue.main.async {
                        self.onEvent(.token(line))
                    }
                }
            }
        }
        
        func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didCompleteWithError error: Error?) {
            DispatchQueue.main.async {
                if let error = error {
                    self.onEvent(.error("❌ خطأ في الشبكة: \(error.localizedDescription)"))
                } else {
                    if !self.buffer.isEmpty {
                        self.onEvent(.token(self.buffer))
                    }
                    self.onEvent(.done)
                }
            }
        }
        
        func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
            if let httpResponse = response as? HTTPURLResponse,
               httpResponse.statusCode != 200 {
                DispatchQueue.main.async {
                    self.onEvent(.error("❌ خطأ من الخادم: \(httpResponse.statusCode)"))
                }
                completionHandler(.cancel)
            } else {
                completionHandler(.allow)
            }
        }
    }
    
    
}

// MARK: - OpenRouter/Custom (OpenAI-style) SSE
extension APIManager {
    func streamOpenAIStyle(
        url: URL,
        apiKey: String?,
        body: [String: Any],
        extraHeaders: [String: String] = [:],
        onEvent: @escaping (StreamEvent) -> Void
    ) {
        guard let key = apiKey else { onEvent(.error("❌ لا توجد مفاتيح نشطة")); return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        extraHeaders.forEach { req.setValue($0.value, forHTTPHeaderField: $0.key) }
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        Task.detached {
            do {
                let (bytes, _) = try await URLSession.shared.bytes(for: req)
                for try await line in bytes.lines {
                    guard line.hasPrefix("data:") else { continue }
                    let payload = String(line.dropFirst(5)).trimmingCharacters(in: .whitespaces)
                    if payload == "[DONE]" { onEvent(.done); break }
                    guard let d = payload.data(using: .utf8),
                          let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any]
                    else { continue }
                    
                    // استخراج من شكل OpenAI: choices[].delta.content
                    if let choices = json["choices"] as? [[String: Any]],
                       let delta = choices.first?["delta"] as? [String: Any],
                       let piece = delta["content"] as? String, !piece.isEmpty {
                        onEvent(.token(piece))
                    }
                }
            } catch {
                onEvent(.error("❌ خطأ في بث OpenAI-style: \(error.localizedDescription)"))
            }
        }
    }
}

// MARK: - Helper: تكوين Body متوافق مع OpenAI-style (لـ OpenRouter/Custom)
private extension APIManager {
    func openAIStyleBody(
        for chat: ChatDTO,
        model: String,
        temperature: Double,
        customPrompt: String?,
        stream: Bool
    ) -> [String: Any] {
        var msgs: [[String: Any]] = []
        if let p = customPrompt, !p.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            msgs.append(["role": "system", "content": p])
        }
        for m in chat.messages {
            var text = m.content
            for a in m.attachments {
                if a.dataType == "text", let t = a.content {
                    text += "\n\n--- محتوى الملف: \(a.name) ---\n\(t)\n--- نهاية الملف ---"
                } else if a.dataType == "image" {
                    // ملاحظة: معظم مقدمي OpenAI-style لا يدعمون الصور هنا؛ نضع إشارة فقط
                    text += "\n\n[صورة مرفقة: \(a.name)]"
                }
            }
            msgs.append(["role": (m.role == .user ? "user" : "assistant"), "content": text])
        }
        return [
            "model": model,
            "messages": msgs,
            "temperature": temperature,
            "stream": stream,
            "max_tokens": 4096
        ]
    }
}

