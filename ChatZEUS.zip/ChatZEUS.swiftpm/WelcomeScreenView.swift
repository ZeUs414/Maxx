import SwiftUI

// MARK: - Welcome Screen للمحادثة الجديدة
struct WelcomeScreenView: View {
    var onPromptSelected: (String) -> Void
    
    // بطاقات الاقتراحات العشوائية
    private let suggestionCards = [
        SuggestionCard(
            title: "ما اخر اخبار",
            subtitle: "الذكاء الاصطناعي",
            color: Color.blue.opacity(0.8)
        ),
        SuggestionCard(
            title: "اكتب قصة قصيرة",
            subtitle: "من النوع الأدبي المفضل لدي",
            color: Color.orange.opacity(0.8)
        ),
        SuggestionCard(
            title: "اكتب لي قصة",
            subtitle: "خيالية قصيرة",
            color: Color.green.opacity(0.8)
        ),
        SuggestionCard(
            title: "أعطني نصائح",
            subtitle: "للتغلب على التسويف",
            color: Color.purple.opacity(0.8)
        )
    ]
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            // الشعار في منتصف الشاشة
            VStack {
                Spacer()
                Image("AppIcon76x76@2x~ipad")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200, height: 200)
                    .foregroundColor(.white)
                    .opacity(0.3)
                Spacer()
            }
            
            // البطاقات في الأسفل (فوق شريط الإدخال مباشرة)
            VStack {
                Spacer()
                LazyVGrid(columns: [
                    GridItem(.flexible(), spacing: 12),
                    GridItem(.flexible(), spacing: 12)
                ], spacing: 12) {
                    ForEach(Array(suggestionCards.enumerated()), id: \.offset) { _, card in
                        SuggestionCardView(card: card) {
                            onPromptSelected(card.title + "\n" + card.subtitle)
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 12) // المسافة فوق شريط الإدخال
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }
}

// MARK: - نموذج بيانات البطاقة
struct SuggestionCard {
    let title: String
    let subtitle: String
    let color: Color
}

// MARK: - عرض البطاقة الواحدة
struct SuggestionCardView: View {
    let card: SuggestionCard
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            VStack(alignment: .leading, spacing: 6) {
                Text(card.title)
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.leading)
                
                Text(card.subtitle)
                    .font(.system(size: 18))
                    .foregroundColor(.white.opacity(0.7))
                    .multilineTextAlignment(.leading)
            }
            .frame(maxWidth: .infinity)
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.white.opacity(0.08))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .strokeBorder(Color.white.opacity(0.1))
                    )
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Extension للضغط
extension View {
    func onPressGesture(onPress: @escaping () -> Void, onRelease: @escaping () -> Void) -> some View {
        self.simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in onPress() }
                .onEnded { _ in onRelease() }
        )
    }
}
